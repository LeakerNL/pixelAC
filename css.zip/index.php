<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OVERWOLF | Next Generation AntiCheat</title>
    <meta name="description"
          content="OVERWOLF AntiCheat | The Next Generation Of Fivem AntiCheat"/>

    <!--Inter UI font-->
    <link href="https://rsms.me/inter/inter-ui.css" rel="stylesheet">
    <meta content='https://media.discordapp.net/attachments/760075782692929536/891648554706305084/Banner.png' property='og:image'>
    <link rel="icon" href="https://cdn.discordapp.com/avatars/804447074702852107/c1433b98d0754edc19efa6c4dcbcfa2c.png" type="image/png" sizes="16x16">
    <!--vendors styles-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">

    <!-- Bootstrap CSS / Color Scheme -->
    <link rel="stylesheet" href="css/default.css" id="theme-color">
</head>
<body>

<!--navigation-->
<section class="smart-scroll">
    <div class="container-fluid">
        <nav class="navbar navbar-expand-md navbar-dark">
            <a class="navbar-brand heading-black" href="index.php">
                OVERWOLF
            </a>
            <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse"
                    data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false"
                    aria-label="Toggle navigation">
                <span data-feather="grid"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="#features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="#pricing">Pricing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="#faq">FAQ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="#blog">News</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll d-flex flex-row align-items-center text-primary" href="Panel">
                            <em data-feather="box" width="18" height="18" class="mr-2"></em>
                            Register And Buy
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</section>

<!--hero header-->
<section class="py-7 py-md-0 bg-hero" id="home">
    <div class="container">
        <div class="row vh-md-100">
            <div class="col-md-8 col-sm-10 col-12 mx-auto my-auto text-center">
                <h1 class="heading-black text-capitalize">We offer you the best capabilities</h1>
                <p class="lead py-3">Overwolf is a antiCheat that makes FiveM a sweeter place . Register & Buy now.</p>
                <a href="Panel">
                    <button class="btn btn-primary d-inline-flex flex-row align-items-center">
                    Buy Now
                        <em class="ml-2" data-feather="arrow-right"></em>
                    </button>
                </a> 
                <a href="https://discord.gg/QUYc2gk3">
                    <button class="btn btn-primary d-inline-flex flex-row align-items-center">
                    Join Discord
                        <em class="ml-2" data-feather="arrow-right"></em>
                    </button>
                </a> 
            </div>
        </div>
    </div>
</section>

<!-- features section -->
<section class="pt-6 pb-7" id="features">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto text-center">
                <h2 class="heading-black">Overwolf offers everything you need.</h2>
                <p class="text-muted lead">Overwolf strives to provide customers with many features and make it easier for users to access products..</p>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-10 mx-auto">
                <div class="row feature-boxes">
                    <div class="col-md-6 box">
                        <div class="icon-box box-primary">
                            <div class="icon-box-inner">
                                <span data-feather="box" width="35" height="35"></span>
                            </div>
                        </div>
                        <h5>Automatically Update</h5>
                        <p class="text-muted">All anti-cheat updates are done by the web and you do not need to update manually.</p>
                    </div>
                    <div class="col-md-6 box">
                        <div class="icon-box box-success">
                            <div class="icon-box-inner">
                                <span data-feather="monitor" width="35" height="35"></span>
                            </div>
                        </div>
                        <h5>Optimized and fastest of all</h5>
                        <p class="text-muted">All anti-cheat code and capabilities have been optimized as much as possible and we try to improve it every day.</p>
                    </div>
                    <div class="col-md-6 box">
                        <div class="icon-box box-danger">
                            <div class="icon-box-inner">
                                <span data-feather="eye" width="35" height="35"></span>
                            </div>
                        </div>
                        <h5>Anti Injection</h5>
                        <p class="text-muted">We will add a client to your scripts to prevent Cheat injections.</p>
                    </div>
                    <div class="col-md-6 box">
                        <div class="icon-box box-info">
                            <div class="icon-box-inner">
                                <span data-feather="camera" width="35" height="35"></span>
                            </div>
                        </div>
                        <h5>ScreenShot Rendering System</h5>
                        <p class="text-muted">AntiCheat Detecte Every Cheat if Player Open The Cheat On Screen .</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--pricing section-->
<section class="py-7 bg-dark section-angle top-right bottom-right" id="pricing">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto text-center">
                <h2 class="text-white heading-black">Choose your pricing plan.</h2>
                <p class="text-light lead">If you would like to become our beta tester, open a ticket in our Discord. </p>
            </div>
        </div>
        <!--pricing tables-->
        <div class="row pt-5 pricing-table">
            <div class="col-12 mx-auto">
                <div class="card-deck pricing-table">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="card-title pt-3">Bronze Plan</h3>
                            <h2 class="card-title text-primary mb-0 pt-4">$15</h2>
                            <div class="text-muted font-weight-medium mt-2">1 Month</div>
                            <ul class="list-unstyled pricing-list">
                                <li>Free Config And Setup</li>
                                <li>IP LimitChange : 4</li>
                                <li>Access to Customers Channel</li>
                                <li>Basic support</li>
                            </ul>
                            <a href="Panel" class="btn btn-primary">
                                Buy Now
                            </a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h3 class="card-title pt-3">Silver Plan</h3>
                            <h2 class="card-title text-info mb-0 pt-4">$40</h2>
                            <div class="text-muted font-weight-medium mt-2">3 Month</div>
                            <ul class="list-unstyled pricing-list">
                                <li>Free Config And Setup</li>
                                <li>IP LimitChange : 12</li>
                                <li>Access to Customers Channel</li>
                                <li>Priority support</li>
                            </ul>
                            <a href="Panel" class="btn btn-info">
                            Buy Now
                            </a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h3 class="card-title pt-3">Gold Plan</h3>
                            <h2 class="card-title text-primary mb-0 pt-4">$85</h2>
                            <div class="text-muted font-weight-medium mt-2">6 Month</div>
                            <ul class="list-unstyled pricing-list">
                                <li>Free Config And Setup</li>
                                <li>IP LimitChange : 30</li>
                                <li>Access to Customers Channel</li>
                                <li>24/7 support</li>
                            </ul>
                            <a href="Panel" class="btn btn-primary">
                            Buy Now
                            </a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h3 class="card-title pt-3">Platinum Plan</h3>
                            <h2 class="card-title text-primary mb-0 pt-4">$120</h2>
                            <div class="text-muted font-weight-medium mt-2">LifeTime</div>
                            <ul class="list-unstyled pricing-list">
                                <li>Free Config And Setup</li>
                                <li>Unlimited IP Change</li>
                                <li>Access to Customers Channel</li>
                                <li>24/7 support</li>
                            </ul>
                            <a href="Panel" class="btn btn-primary">
                            Buy Now
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-6">
            <div class="col-md-4 mr-auto">
                <h3>Everything is covered.</h3>
            </div>
            <div class="col-md-7 offset-md-1">
                <ul class="features-list">
                    <li>Weekly Selcy Update</li>
                    <li>Access to new features</li>
                    <li>Free Support</li>
                    <li>99.9% Uptime</li>
                    <li>Global Ban</li>
                    <li>Auto Setup</li>
                </ul>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-8 col-12 divider top-divider mx-auto pt-5 text-center">
                <h3>Try Beta Tester</h3>
                <p class="mb-4">If you would like to become our beta tester, open a ticket in our Discord.</p>
                <a href="https://discord.gg/QUYc2gk3">
                    <button class="btn btn-primary">
                        Join Our Discord
                    </button>
                </a> 
            </div>
        </div>
    </div>
</section>

<!--faq section-->
<section class="py-7" id="faq">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto text-center">
                <h2>Frequently asked questions</h2>
                <p class="text-muted lead">Answers to most common questions.</p>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-10 mx-auto">
                <div class="row">
                    <div class="col-md-6 mb-5">
                        <h6>Can I Buy?</h6>
                        <p class="text-muted">Official licenses can be safely purchased, only through our Overwolf website and the authorized resellers.
                            The website will let you pay with Paypal / IDPAY / cryptocurrency for now
                            You can find our official resellers only on the Overwolf discord for Other Payment Method.</p>
                    </div>
                    <div class="col-md-6 mb-5">
                        <h6>How Can i Activate License ?</h6>
                        <p class="text-muted">Website: When your payment is done, do a screenshot of your Order ID, and open a ticket on Overwolf discord, and wait for the activation by our staff.
                            Reseller: If you're buying via an authorized reseller, your license will be activated by him.</p>
                    </div>
                    <div class="col-md-6 mb-5">
                        <h6>DISCLAIMER</h6>
                        <p class="text-muted">Scammers try to impersonate resellers and official staff!
                            Check the names and links if they're authentic or not.
                            Always check if the website link or the username contains special characters, trying to mimic the real ones.
                            The real authorized Overwolf resellers and staff, are ONLY inside the official discord.
                        </p>
                    </div>
                    <div class="col-md-6 mb-5">
                        <h6>ExternalCheats</h6>
                        <p class="text-muted">OVERWOLF may **not** protect you from External Cheats
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6 mx-auto text-center">
                <h5 class="mb-4">Have questions?</h5>
                <a href="#" class="btn btn-primary">Contact us</a>
            </div>
        </div>
    </div>
</section>

<!--news section-->
<section class="py-7 bg-dark section-angle top-left bottom-left" id="blog">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto text-center">
                <h2 class="heading-black">News from Overwolf.</h2>
                <p class="text-muted lead">What's new at Overwolf.</p>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-4">
                <div class="card">
                    <a href="#">
                        <img class="card-img-top img-raised" src="img/Banner.png" alt="Blog 1">
                    </a>
                    <div class="card-body">
                        <a href="#" class="card-title mb-2"><h5>We are working hard on 1.8 version</h5></a>
                        <p class="text-muted small-xl mb-2">Sep 25, 2021</p>
                        <p class="card-text">We Are Working Hard On This Version To Make Stable And Optimized Version. <a href="#">Learn more</a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <a href="#">
                        <img class="card-img-top img-raised" src="img/Banner.png" alt="Blog 2">
                    </a>
                    <div class="card-body">
                        <a href="#" class="card-title mb-2"><h5>Fix Usage problem in version 1.7</h5></a>
                        <p class="text-muted small-xl mb-2">Sep 2, 2021</p>
                        <p class="card-text">We Fixed High Timing in 1.7 Version. <a href="#">Learn more</a></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <a href="#">
                        <img class="card-img-top img-raised" src="img/Banner.png" alt="Blog 3">
                    </a>
                    <div class="card-body">
                        <a href="#" class="card-title mb-2"><h5>Version 1.7 Has Been Released</h5></a>
                        <p class="text-muted small-xl mb-2">August 8, 2021</p>
                        <p class="card-text">Version 1.7 Released You Can Buy It Now On Website. <a href="#">Learn more</a></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-6">
            <div class="col-md-6 mx-auto text-center">
                <a href="#" class="btn btn-primary">View all posts</a>
            </div>
        </div>
    </div>
</section>

<!--footer-->
<footer class="py-6">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 mr-auto">
                <h5>OVERWOLF.XYZ</h5>
            </div>
            <div class="col-sm-2">
                <h5>Legal</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Privacy</a></li>
                    <li><a href="#">Terms</a></li>
                    <li><a href="#">Refund policy</a></li>
                </ul>
            </div>
            <div class="col-sm-2">
                <h5>Partner</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Refer a friend</a></li>
                    <li><a href="#">Affiliates</a></li>
                </ul>
            </div>
            <div class="col-sm-2">
                <h5>Help</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Support</a></li>
                    <li><a href="Panel">Log in</a></li>
                </ul>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-12 text-muted text-center small-xl">
                &copy; 2021 Overwolf - All Rights Reserved
            </div>
        </div>
    </div>
</footer>

<!--scroll to top-->
<div class="scroll-top">
    <i class="fa fa-angle-up" aria-hidden="true"></i>
</div>


<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.7.3/feather.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>